
define e = Character(_("Example"))
screen preferences():
    label _("Display")
    text "This arbitrary literal is not a translation key."
    textbutton _("Window") action Preference("display", "window")
label start: # source comment is not part of the identifier
    e "Hello [name!q]."
    "Narration."
    menu:
        "Choose":
            e "Nested dialogue."
    python:
        raise RuntimeError("NEVER EXECUTE")
        ignored = '_("Not a key")'
    # _("Not a comment key")
    voice "audio.ogg"
    e "Voice group is excluded."
    e "Attributes are excluded." happy
    return "Not dialogue."
