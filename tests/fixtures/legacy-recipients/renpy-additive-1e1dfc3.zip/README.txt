UnityTranslator Ren'Py additive language patch

1. Close the game. Extract this ZIP outside the game folder.
2. Run Install.cmd and select the ORIGINAL game's folder once.
3. Review the exact new-file plan and type INSTALL. No game is launched.
4. Run Play-Translated.cmd in the game folder to select the translated language.

The game is NOT copied. Only approved game/tl/<language>/*.rpy files, a launcher
and small installer/ownership records are added. Original scripts and archives
are not replaced. Existing paths or language namespaces cause refusal; no backup
is needed because no original file is overwritten. The original language remains.
Normal saves are used. Playing may update saves, caches, logs and Python bytecode
as usual; the patch does not back up or roll back gameplay data.

To uninstall: close the game, run Remove.cmd and select the same game folder.
Review the removal plan and type REMOVE. Only unchanged receipt-owned additions
are removed. Modified, linked and unknown files are preserved; audit receipts remain.
Ren'Py may create compiled .rpyc files beside the translations. Those files are
not automatically claimed as owned. If present, automatic removal stops BEFORE
deleting translations, since orphaned .rpyc files can keep a translation active.
Review/remove those generated sidecars manually, then rerun Remove.cmd.
Do not delete unrelated game .rpyc files.

Keep this ZIP for removal. Updates require removing the old patch and creating
a new package; existing files are never silently adopted or overwritten.
Recipients need Windows PowerShell, not Python, a model or UnityTranslator.
Compatibility and coverage are limited to the matching reviewed build.
