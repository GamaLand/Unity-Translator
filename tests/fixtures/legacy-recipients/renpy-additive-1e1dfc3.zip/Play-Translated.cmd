@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0.unitytranslator\renpy-additive\271e1a01290843319598a74a7daff6ea\renpy-copy.ps1" -Action Launch
if errorlevel 1 pause
