﻿UnityTranslator shareable translation patch

Extract the ZIP into a separate folder. Run Install.cmd and choose the game folder.
The game must be closed. UnityTranslator, Python, LM Studio and a model are not required.
The installer adds UnityTranslatorPatch, winhttp.dll and doorstop_config.ini.
Existing files or folders are never overwritten. Remove an earlier installation first.
Use the original UnityTranslator project to remove a project-managed trial.
Uninstall.cmd removes only this package's files with matching ownership and hashes.
Modified files are preserved. If you move the game, uninstall and reinstall the patch.
The loader path is generated on the recipient's computer.
Kur.cmd and Kaldir.cmd are equivalent legacy launcher names.
Experimental: matching Windows x64 game required. Check fonts, RTL layout and plurals.
No game files, model or project database are included.
Component licenses and sources are under UnityTranslatorPatch/support.
