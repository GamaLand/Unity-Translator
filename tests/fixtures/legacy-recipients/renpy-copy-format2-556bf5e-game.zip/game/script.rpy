label start:
    e "One."
    e "Two."
