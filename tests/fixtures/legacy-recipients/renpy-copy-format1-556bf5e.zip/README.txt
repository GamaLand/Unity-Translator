UnityTranslator Ren'Py translated-copy installation package

1. Close the game. Extract this package outside the original game.
2. Run Install.cmd. Select the matching original game and a separate output parent.
3. Review the exact create-new file plan and type INSTALL. No game is launched.
4. Use Play-Translated.cmd in the new copy to explicitly launch the selected language.
The recipient needs Windows PowerShell, not Python, a model or UnityTranslator.
Original saves/logs/caches are not copied. The new copy starts with separate saves.
Remove.cmd removes only unchanged owned copy files. Runtime-created or modified files
are preserved and reported; a partial removal is never reported as complete.
No original game file is distributed in this ZIP. Keep your original game.
Coverage and translation quality remain limited to the reviewed source subset.
