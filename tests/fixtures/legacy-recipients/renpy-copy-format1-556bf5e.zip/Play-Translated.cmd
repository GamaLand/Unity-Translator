@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0.unitytranslator\renpy-copy\renpy-copy.ps1" -Action Launch
if errorlevel 1 pause
