﻿UnityTranslator paylaşılabilir çeviri

ZIP'i ayrı bir klasöre çıkarın. Kur.cmd dosyasını açıp oyun klasörünü seçin.
Oyun kapalı olmalı. UnityTranslator, Python, LM Studio veya model gerekmez.
Yeni UnityTranslatorPatch klasörü, winhttp.dll ve doorstop_config.ini eklenir.
Mevcut dosya/klasör varsa kurulum durur; başka modu veya önceki kurulumu ezmez.
Mevcut denemeyi kaldırmak için onu kuran UnityTranslator projesini kullanın.
Kaldir.cmd yalnızca bu paketin sahipliği/hash'i eşleşen eklerini kaldırır.
Değiştirilmiş dosyalar korunur. Oyun klasörünü taşırsanız kaldırıp yeniden kurun.
Yükleyici yolu alıcının bilgisayarında oluşturulur; geliştirici yolu içermez.
Uyumluluk deneyseldir; yalnızca hash'leri eşleşen Windows x64 oyun sürümü.
Oyun dosyası, model, proje veritabanı veya kaynak İngilizce metin dahil değildir.
Bileşen lisans/kaynakları UnityTranslatorPatch/support altındadır.
